#include "adjlist.h"

int main()
{
    int V, u, v, w;
    scanf("%d", &V);
    Graph G = initGraph(V);

    while (scanf("%d %d %d", &u, &v, &w) != EOF)
    {
        insertArc(G, u, v, w);
    }

    if (!bellmanFord(G))
    {
        printf("Ciclo negativo detectado! Encerrando...\n");
        freeGraph(G);
        return 1;
    }

    for (int i = 0; i < V; i++)
    {
        dijkstra(G, i);
        if (i != V - 1)
            printf("\n");
    }

    freeGraph(G);
    return 0;
}