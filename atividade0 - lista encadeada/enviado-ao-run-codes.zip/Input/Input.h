#include "../Util/Util.h"
#include "../Lista/Lista.h"
#include "../Item/Item.h"

#define MAX_COMMAND 100

void input_padrao(LISTA **lista);
